using UnityEngine;

namespace ReachKillshotOverlay.Scripts.Features
{
    public class CoroutineRunner : MonoBehaviour
    {
    }
}