using HarmonyLib;

namespace LuckyLooter.Harmony.Patches
{
    [HarmonyPatch(typeof(ItemActionEntryCraft))]
    [HarmonyPatch("OnActivated")]
    public class ItemActionEntryCraftPatch
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}