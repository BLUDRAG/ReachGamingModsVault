using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace BossRaids.Scripts
{
    public class CommandInterpreter : MonoBehaviour
    {
        public static void Init()
        {
            GameObject sceneObject = new GameObject($"{Assembly.GetExecutingAssembly().FullName} - Command Interpreter");
            DontDestroyOnLoad(sceneObject);
            CommandInterpreter commandInterpreter = sceneObject.AddComponent<CommandInterpreter>();

            ModEvents.GameMessage.RegisterHandler(commandInterpreter.InterpretCommand);
            ModEvents.ChatMessage.RegisterHandler(commandInterpreter.InterpretCommand);
        }

        private bool InterpretCommand(ClientInfo cInfo, EChatType type, int _v3, string msg, string mainName, bool
                                          localizeMain, List<int> _v7)
        {
            if(!string.IsNullOrEmpty(msg) && mainName != "Server")
            {
                if(msg == "bossraids spawn random")
                {
                    StartCoroutine(GameInteractions.SpawnRandomBoss());

                    return false;
                }

                return true;
            }

            return true;
        }

        public bool InterpretCommand(ClientInfo cInfo,        EnumGameMessages type, string msg, string mainName,
                                     bool       localizeMain, string           secondaryName, bool localizeSecondary)
        {
            Log.Warning($"{!string.IsNullOrEmpty(msg)} | {cInfo != null} | {mainName != "Server"}");
            if(!string.IsNullOrEmpty(msg) && cInfo != null && mainName != "Server")
            {
                if(msg == "bossraids spawn random")
                {
                    StartCoroutine(GameInteractions.SpawnRandomBoss());

                    return false;
                }

                return true;
            }

            return true;
        }
    }
}