using System;

namespace BossRaids.Scripts.Data
{
    [Serializable]
    public class BossRaidsData
    {
        public int NextSpawnDay;
        public int NextSpawnHour;
        public int NextSpawnMinute;
    }
}