using System.Reflection;
using UnityEngine;

namespace BossRaids.Scripts
{
    public class CommandInterpreter : MonoBehaviour
    {
        public static void Init()
        {
            GameObject sceneObject = new GameObject($"{Assembly.GetExecutingAssembly().FullName} - Command Interpreter");
            DontDestroyOnLoad(sceneObject);
            CommandInterpreter commandInterpreter = sceneObject.AddComponent<CommandInterpreter>();

            ModEvents.GameMessage.RegisterHandler(commandInterpreter.InterpretCommand);
        }

        private bool InterpretCommand(ClientInfo cInfo,        EnumGameMessages type, string msg, string mainName,
                                      bool       localizeMain, string           secondaryName, bool localizeSecondary)
        {
            if(string.IsNullOrEmpty(msg) || cInfo == null || mainName == "Server") return true;

            if(msg == "bossraids spawn random")
            {
                StartCoroutine(GameInteractions.SpawnRandomBoss());
                return false;
            }

            return true;
        }
    }
}