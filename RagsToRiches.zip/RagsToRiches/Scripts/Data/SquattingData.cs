using System;

namespace RagsToRiches.Scripts.Data
{
    [Serializable]
    public sealed class SquattingData
    {
        public string Prefab;
        public int    Day;
    }
}