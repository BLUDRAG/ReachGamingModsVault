using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using PersonalArtworker.Scripts.Entities;
using UnityEngine;

namespace PersonalArtworker.Scripts.Data
{
    public static class DataManagement
    {
        private static List<ArtworkEntity> _queuedArtwork = new List<ArtworkEntity>();

        public const string DEFAULT_IMAGE_ID = "5a68e8a120b29c38202e885f18f27c8078e1582b22c543d0b0a020a74d917a3d";
        
        private static string _dataPath;

        public static void Init(Mod modInstance)
        {
            _dataPath = Path.Combine(modInstance.Path, "Data");
        }

        public static void ProcessImage(byte[] imageData, string guid)
        {
            string path = Path.Combine(_dataPath, guid);

            if(!File.Exists(path))
            {
                File.WriteAllBytes(path, imageData);
            }
        }
        
        public static byte[] LoadImage(string guid)
        {
            string path = Path.Combine(_dataPath, guid);
            return File.Exists(path) ? File.ReadAllBytes(path) : null;
        }

        public static async Task<string> GetImageID(Texture2D texture)
        {
            byte[] textureData = GetReadableTexture(texture).EncodeToPNG();

            Task<string> task = Task.Run(() =>
                                         {
                                             string str       = Encoding.ASCII.GetString(textureData);
                                             SHA256 sha256    = SHA256.Create();
                                             byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(str));
                                             sha256.Dispose();
                                             string id = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                                             ProcessImage(textureData, id);
                                             SendImagePackage(textureData, id);
                                             return id;
                                         });

            return await task;
        }

        private static void SendImagePackage(byte[] textureData, string guid)
        {
            NetPackage package = NetPackageManager
                                .GetPackage<SendImageNetPackage>()
                                .Setup(textureData, guid);

            SingletonMonoBehaviour<ConnectionManager>.Instance.SendPackage(package);
        }

        private static Texture2D GetReadableTexture(Texture2D texture)
        {
            Texture2D readableTexture = texture;

            if(!texture.isReadable)
            {
                RenderTexture temporaryRenderTexture = new RenderTexture(texture.width, texture.height,
                                                                         0, RenderTextureFormat.ARGB32,
                                                                         RenderTextureReadWrite.Linear);

                RenderTexture previousActiveRenderTexture = RenderTexture.active;
                RenderTexture.active = temporaryRenderTexture;
                Graphics.Blit(texture, temporaryRenderTexture);

                readableTexture = new Texture2D(texture.width, texture.height, TextureFormat.ARGB32, 1, true);

                readableTexture.ReadPixels(new Rect(0, 0, temporaryRenderTexture.width, temporaryRenderTexture.height),
                                           0, 0, true);

                readableTexture.Apply(true);

                RenderTexture.active = previousActiveRenderTexture;
                temporaryRenderTexture.Release();
            }

            return readableTexture;
        }

        public static async void LoadQueuedArtwork()
        {
            foreach(ArtworkEntity entity in _queuedArtwork)
            {
                await entity.LoadImage();
            }
        }
    }
}