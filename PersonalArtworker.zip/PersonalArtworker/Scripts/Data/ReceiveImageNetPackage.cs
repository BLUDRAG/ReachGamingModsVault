namespace PersonalArtworker.Scripts.Data
{
    public class ReceiveImageNetPackage : NetPackage
    {
        private byte[] _imageData;
        private string _guid;

        public ReceiveImageNetPackage Setup(byte[] imageData, string guid)
        {
            _imageData = imageData;
            _guid      = guid;

            return this;
        }

        public override void read(PooledBinaryReader _reader)
        {
            _guid = _reader.ReadString();
            int length = _reader.ReadInt32();
            _imageData = _reader.ReadBytes(length);
        }

        public override void write(PooledBinaryWriter _writer)
        {
            base.write(_writer);
            _writer.Write(_guid);
            _writer.Write(_imageData.Length);
            _writer.Write(_imageData);
        }

        public override void ProcessPackage(World _world, GameManager _callbacks)
        {
            DataManagement.ProcessImage(_imageData, _guid);
            DataManagement.LoadQueuedArtwork();
        }

        public override int GetLength()
        {
            return (_guid.Length * 2) + _imageData.Length;
        }

        public override NetPackageDirection PackageDirection => NetPackageDirection.ToClient;
    }
}