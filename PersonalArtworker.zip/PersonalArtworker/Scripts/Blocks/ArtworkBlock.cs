using PersonalArtworker.Scripts.Entities;
using PersonalArtworker.Scripts.Features;
using SimpleFileBrowser;
using UnityEngine;

namespace PersonalArtworker.Scripts.Blocks
{
    public class ArtworkBlock : Block
    {
        private BlockActivationCommand[] commands = new BlockActivationCommand[]
                                                    {
                                                        new BlockActivationCommand("take",   "hand",   true),
                                                        new BlockActivationCommand("ResizeArtwork", "wrench", true),
                                                        new BlockActivationCommand("ImportArtwork", "search", true),
                                                    };

        public override void OnBlockAdded(WorldBase _world, Chunk _chunk, Vector3i _blockPos, BlockValue _blockValue)
        {
            base.OnBlockAdded(_world, _chunk, _blockPos, _blockValue);

            if(!(_world.GetTileEntity(_chunk.ClrIdx, _blockPos) is ArtworkEntity))
            {
                ArtworkEntity artworkEntity = new ArtworkEntity(_chunk);
                artworkEntity.localChunkPos = World.toBlock(_blockPos);
                _chunk.AddTileEntity(artworkEntity);
            }
        }

        public override void OnBlockRemoved(WorldBase world, Chunk _chunk, Vector3i _blockPos, BlockValue _blockValue)
        {
            base.OnBlockRemoved(world, _chunk, _blockPos, _blockValue);

            if(!GameInteractions.GameInteractions.IsServer() && world.GetTileEntity(_chunk.ClrIdx, _blockPos) is ArtworkEntity artworkEntity)
            {
                artworkEntity.Reset();
            }

            _chunk.RemoveTileEntityAt<ArtworkEntity>((World)world, World.toBlock(_blockPos));
        }

        public override void OnBlockEntityTransformAfterActivated(WorldBase       _world, Vector3i _blockPos, int _cIdx, BlockValue _blockValue,
                                                                  BlockEntityData _ebcd)
        {
            base.OnBlockEntityTransformAfterActivated(_world, _blockPos, _cIdx, _blockValue, _ebcd);

            if(GameInteractions.GameInteractions.IsServer())
            {
                return;
            }

            if(_world.GetTileEntity(_cIdx, _blockPos) is ArtworkEntity artworkEntity)
            {
                InjectFeatures(this, artworkEntity, _ebcd.transform);
            }
        }

        public override BlockActivationCommand[] GetBlockActivationCommands(WorldBase _world,    BlockValue  _blockValue, int _clrIdx,
                                                                            Vector3i  _blockPos, EntityAlive _entityFocusing)
        {
            return commands;
        }

        public override bool OnBlockActivated(int        _indexInBlockActivationCommands, WorldBase   _world, int _cIdx, Vector3i _blockPos,
                                              BlockValue _blockValue,                     EntityAlive _player)
        {
            switch(_indexInBlockActivationCommands)
            {
                case 0:
                    return base.OnBlockActivated(_indexInBlockActivationCommands, _world, _cIdx, _blockPos, _blockValue,
                                                 _player);
                case 1:
                {
                    if(_world.GetTileEntity(_cIdx, _blockPos) is ArtworkEntity artworkEntity)
                    {
                        artworkEntity.ToggleResizer();
                    }

                    break;
                }
                case 2:
                {
                    GameInteractions.GameInteractions.ToggleImportingState(true);

                    FileBrowser.ShowLoadDialog(success =>
                                               {
                                                   GameInteractions.GameInteractions.ToggleImportingState(false);

                                                   if(_world.GetTileEntity(_cIdx, _blockPos) is ArtworkEntity artworkEntity)
                                                   {
                                                       artworkEntity.ApplyImage(success[0]);
                                                   }
                                               },
                                               () =>
                                               {
                                                   GameInteractions.GameInteractions.ToggleImportingState(false);
                                               }, FileBrowser.PickMode.Files, false, null, null,
                                               "Import Artwork", "Import");

                    break;
                }
            }

            return true;
        }

        private void InjectFeatures(ArtworkBlock block, ArtworkEntity artworkEntity, Transform root)
        {
            ArtworkFeatureInjector.InjectFeatures(block, artworkEntity, root);
        }
    }
}