using System.Threading.Tasks;
using PersonalArtworker.Scripts.Blocks;
using PersonalArtworker.Scripts.Data;
using PersonalArtworker.Scripts.Features;
using UnityEngine;

namespace PersonalArtworker.Scripts.Entities
{
    public class ArtworkEntity : TileEntity
    {
        public const int TILE_ENTITY_TYPE = 128;
        
        public bool Initialized;
        
        private readonly ArtworkFeatureController _featureController;
        private          MeshRenderer             _meshRenderer;
        private          Vector3                  _loadedPosition;
        private          Vector3                  _loadedScale;
        private          string                   _guid;
        private          bool                     _dataLoaded;
        
        public ArtworkEntity(Chunk _chunk) : base(_chunk)
        {
            _featureController = new ArtworkFeatureController();
            _guid              = DataManagement.DEFAULT_IMAGE_ID;
        }

        public override void Reset()
        {
            _featureController.Reset();
        }

        public override TileEntityType GetTileEntityType()
        {
            return (TileEntityType)TILE_ENTITY_TYPE;
        }

        public ArtworkFeatureController Init(ArtworkBlock block, MeshRenderer artworkRenderer, GameObject root)
        {
            _meshRenderer = artworkRenderer;
            _featureController.Init(block, artworkRenderer.transform, root, this);
            _featureController.PrepareImageProcessor(artworkRenderer);
            LoadData();
            Initialized = true;
            return _featureController;
        }

        private void LoadData()
        {
            if(!_dataLoaded) return;
            _featureController.LoadData(_loadedPosition, _loadedScale, _guid);
            _dataLoaded = false;
        }

        public async Task LoadImage()
        {
            await _featureController.LoadImage(_guid);
        }

        public void ToggleResizer()
        {
            _featureController.ToggleResizer();
        }

        public async void ApplyImage(string imagePath)
        {
            await _featureController.ApplyImage(imagePath);
            _guid = await DataManagement.GetImageID((Texture2D)_meshRenderer.material.mainTexture);
            _featureController.SaveData();
        }

        public override void OnUnload(World world)
        {
            base.OnUnload(world);
            bool isServer = GameInteractions.GameInteractions.IsServer();

            if(isServer)
            {
                return;
            }

            _featureController.DisableResizer();
        }

        public override void write(PooledBinaryWriter _bw, StreamModeWrite _eStreamMode)
        {
            base.write(_bw, _eStreamMode);
            bool isServer = GameInteractions.GameInteractions.IsServer();
            
            (Vector3 position, Vector3 scale) = isServer ? (_loadedPosition, _loadedScale) : _featureController.GetSizeData();
            _bw.Write(position.x);
            _bw.Write(position.y);
            _bw.Write(position.z);
            _bw.Write(scale.x);
            _bw.Write(scale.y);
            _bw.Write(scale.z);
            _bw.Write(_guid);
        }

        public override void read(PooledBinaryReader _br, StreamModeRead _eStreamMode)
        {
            base.read(_br, _eStreamMode);
            _loadedPosition = new Vector3(_br.ReadSingle(), _br.ReadSingle(), _br.ReadSingle());
            _loadedScale    = new Vector3(_br.ReadSingle(), _br.ReadSingle(), _br.ReadSingle());
            _guid           = _br.ReadString();
            _dataLoaded     = true;
        }
    }
}