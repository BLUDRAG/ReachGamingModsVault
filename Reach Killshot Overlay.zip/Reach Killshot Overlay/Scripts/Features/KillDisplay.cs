using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using ReachKillshotOverlay.Scripts.AssetManagement;
using UnityEngine;
using UnityEngine.UI;

namespace ReachKillshotOverlay.Scripts.Features
{
    public static class KillDisplay
    {
        private static CoroutineRunner _runner;
        private static Animator        _overlay;
        private static Text            _text;
        private static Queue<Text>     _killQueue  = new Queue<Text>();
        private static bool            _displaying = false;
        private static WaitForSeconds  _queueDelay = new WaitForSeconds(0.75f);
        private static WaitForSeconds  _fadeDelay  = new WaitForSeconds(0.33f);

        private static readonly int      ShowTrigger    = Animator.StringToHash("Show");
        private static readonly int      FadeTrigger    = Animator.StringToHash("Fade");
        private const           string   _canvasPath    = "Assets/ReachKillshotOverlayCanvas.unity3d";
        private const           string   _canvasName    = "ReachKillshotOverlayCanvas";
        private const           string   _formattedText = "<color=#dd2222>{0}</color> Killed";

        public static void Init(Mod modInstance)
        {
            _ = LoadCanvas(modInstance);
            InitializeCoroutineRunner();
        }

        private static async Task LoadCanvas(Mod modInstance)
        {
            GameObject asset = await AssetBundleLoader.LoadContent(Path.Combine(modInstance.Path, _canvasPath),
                                                                   _canvasName);
            if(asset is null) return;

            GameObject canvas = Object.Instantiate(asset);
            Object.DontDestroyOnLoad(canvas);
            _overlay = canvas.transform.Find("Overlay").GetComponent<Animator>();
            _text    = canvas.transform.Find("Text").GetComponent<Text>();
        }

        private static void InitializeCoroutineRunner()
        {
            _runner = new GameObject("Coroutine Runner").AddComponent<CoroutineRunner>();
            Object.DontDestroyOnLoad(_runner.gameObject);
        }

        public static void QueueKill(string entityName)
        {
            Text text = Object.Instantiate(_text, _text.transform.parent);
            text.text = string.Format(_formattedText, entityName);
            _killQueue.Enqueue(text);

            if(!_displaying)
            {
                _runner.StartCoroutine(DisplayKills());
            }
        }

        private static IEnumerator DisplayKills()
        {
            _displaying = true;
            _overlay.SetTrigger(ShowTrigger);

            while(_killQueue.Count > 0)
            {
                Text       text       = _killQueue.Dequeue();
                GameObject gameObject = text.gameObject;
                gameObject.SetActive(true);
                
                yield return _queueDelay;
                Object.Destroy(gameObject);
            }

            _overlay.SetTrigger(FadeTrigger);
            yield return _fadeDelay;
            _displaying = false;
        }
    }
}